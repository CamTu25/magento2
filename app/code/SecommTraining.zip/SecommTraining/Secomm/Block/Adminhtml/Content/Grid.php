<?php
namespace SecommTraining\Secomm\Block\Adminhtml\Content;

class Grid extends \Magento\Backend\Block\Widget\Grid
{

}
?>
